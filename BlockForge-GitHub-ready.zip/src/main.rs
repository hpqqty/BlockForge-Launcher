mod auth;
use auth::AuthEvent;
use eframe::egui;
use serde::Deserialize;
use sha1::{Digest, Sha1};
use std::{collections::HashMap, fs, io::Write, path::{Path, PathBuf}, sync::mpsc::{self, Receiver, Sender}, thread, time::Duration};

const MANIFEST: &str = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json";

#[derive(Debug, Clone, Deserialize)]
struct Version { id: String, #[serde(rename="type")] kind: String, url: String }
#[derive(Deserialize)]
struct Manifest { versions: Vec<Version> }
#[derive(Deserialize)]
struct Download { url: String, sha1: Option<String>, size: Option<u64>, path: Option<String> }
#[derive(Deserialize)]
struct Downloads { client: Download }
#[derive(Deserialize)]
struct Library { downloads: Option<LibraryDownloads>, rules: Option<Vec<Rule>> }
#[derive(Deserialize)]
struct LibraryDownloads { artifact: Option<Download>, classifiers: Option<HashMap<String, Download>> }
#[derive(Deserialize)]
struct Rule { action: String, os: Option<OsRule>, features: Option<serde_json::Value> }
#[derive(Deserialize)]
struct OsRule { name: Option<String>, arch: Option<String>, version: Option<String> }
#[derive(Deserialize)]
struct VersionInfo { downloads: Downloads, libraries: Vec<Library>, #[serde(rename="assetIndex")] asset_index: Option<Download> }
#[derive(Deserialize)]
struct AssetIndex { objects: HashMap<String, Asset> }
#[derive(Deserialize)]
struct Asset { hash: String, size: u64 }

enum Event { Versions(Vec<Version>), Progress(String, usize, usize), Done(String), Error(String) }

struct App {
    versions: Vec<Version>, filter: String, snapshots: bool, selected: Option<Version>,
    status: String, busy: bool, completed: usize, total: usize,
    rx: Receiver<Event>, tx: Sender<Event>,
    minecraft_path: String,
    client_id: String, auth_rx: Receiver<AuthEvent>, auth_tx: Sender<AuthEvent>,
    auth_busy: bool, auth_code: String, auth_url: String, auth_message: String,
    player: Option<(String, String)>,
}
impl App {
    fn new() -> Self {
        let (tx, rx) = mpsc::channel();
        let default_dir = std::env::var("APPDATA").map(|v| PathBuf::from(v).join(".minecraft"))
            .unwrap_or_else(|_| PathBuf::from(".minecraft"));
        let (auth_tx, auth_rx) = mpsc::channel();
        let mut app = Self { versions: vec![], filter: String::new(), snapshots: false, selected: None,
            status: "Ready. Click Refresh versions.".into(), busy: false, completed: 0, total: 0,
            rx, tx, minecraft_path: default_dir.to_string_lossy().to_string(),
            client_id: String::new(), auth_rx, auth_tx, auth_busy: false,
            auth_code: String::new(), auth_url: String::new(), auth_message: String::new(), player: None };
        app.refresh(); app
    }
    fn refresh(&mut self) {
        if self.busy { return; }
        self.busy = true; self.status = "Fetching Mojang versions...".into();
        let tx = self.tx.clone();
        thread::spawn(move || {
            let result = (|| -> Result<Vec<Version>, String> {
                let client = client()?;
                let response = client.get(MANIFEST).send().map_err(|e| e.to_string())?.error_for_status().map_err(|e| e.to_string())?;
                let body = response.text().map_err(|e| e.to_string())?;
                let data: Manifest = serde_json::from_str(&body).map_err(|e| format!("Manifest JSON: {e}"))?;
                Ok(data.versions)
            })();
            let _ = tx.send(match result { Ok(v) => Event::Versions(v), Err(e) => Event::Error(e) });
        });
    }
    fn start_login(&mut self) {
        if self.auth_busy { return; }
        self.auth_busy = true;
        self.auth_code.clear(); self.auth_url.clear();
        self.auth_message = "Requesting Microsoft sign-in code...".into();
        let tx = self.auth_tx.clone(); let id = self.client_id.trim().to_string();
        thread::spawn(move || auth::sign_in(id, tx));
    }
    fn install(&mut self) {
        if self.busy { return; }
        let Some(version) = self.selected.clone() else { self.status = "Select a version first.".into(); return; };
        self.busy = true; self.completed = 0; self.total = 0;
        self.status = format!("Installing {}...", version.id);
        let tx = self.tx.clone(); let root = PathBuf::from(&self.minecraft_path);
        thread::spawn(move || {
            let result = install_version(&version, &root, &tx);
            let _ = tx.send(match result { Ok(()) => Event::Done(format!("Installed {} files successfully. Game launching is coming in v0.5.", version.id)), Err(e) => Event::Error(e) });
        });
    }
}
impl eframe::App for App {
    fn update(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        while let Ok(event) = self.rx.try_recv() {
            match event {
                Event::Versions(v) => { self.versions = v; self.busy = false; self.status = format!("Loaded {} versions", self.versions.len()); }
                Event::Progress(s, n, total) => { self.status = s; self.completed = n; self.total = total; }
                Event::Done(s) | Event::Error(s) => { self.status = s; self.busy = false; }
            }
        }
        while let Ok(event) = self.auth_rx.try_recv() {
            match event {
                AuthEvent::Code { code, url, message } => {
                    self.auth_code = code; self.auth_url = url; self.auth_message = message;
                }
                AuthEvent::Status(s) => self.auth_message = s,
                AuthEvent::SignedIn { username, uuid } => {
                    self.player = Some((username, uuid)); self.auth_busy = false;
                    self.auth_message = "Minecraft Java account verified!".into();
                    self.auth_code.clear();
                }
                AuthEvent::Error(e) => {
                    self.auth_busy = false; self.auth_message = format!("Sign-in failed: {e}");
                }
            }
        }
        egui::CentralPanel::default().show(ctx, |ui| {
            ui.heading("⛏ BlockForge Launcher");
            ui.label("v0.4 · Independent Minecraft installer + Microsoft sign-in");
            ui.collapsing("Microsoft account (v0.4)", |ui| {
                if let Some((name, uuid)) = &self.player {
                    ui.label(format!("Signed in: {name}"));
                    ui.small(format!("Minecraft UUID: {uuid}"));
                    if ui.button("Sign out").clicked() { self.player = None; self.auth_message = "Signed out.".into(); }
                } else {
                    ui.label("Microsoft application (client) ID:");
                    ui.add_enabled(!self.auth_busy, egui::TextEdit::singleline(&mut self.client_id).desired_width(360.0));
                    ui.small("Register a public-client application in Microsoft Entra. Do not enter your Microsoft password here.");
                    if ui.add_enabled(!self.auth_busy && !self.client_id.trim().is_empty(), egui::Button::new("Sign in with Microsoft")).clicked() { self.start_login(); }
                    if !self.auth_code.is_empty() {
                        ui.horizontal(|ui| { ui.label("Code:"); ui.strong(&self.auth_code); if ui.button("Copy code").clicked() { ui.ctx().copy_text(self.auth_code.clone()); } });
                        ui.hyperlink_to("Open Microsoft verification page", &self.auth_url);
                    }
                }
                if !self.auth_message.is_empty() { ui.label(&self.auth_message); }
            });
            ui.separator();
            ui.horizontal(|ui| {
                if ui.add_enabled(!self.busy, egui::Button::new("↻ Refresh versions")).clicked() { self.refresh(); }
                ui.checkbox(&mut self.snapshots, "Include snapshots");
                ui.label("Search:"); ui.text_edit_singleline(&mut self.filter);
            });
            ui.add_space(8.0);
            ui.label("Minecraft data folder:");
            ui.add_enabled(!self.busy, egui::TextEdit::singleline(&mut self.minecraft_path).desired_width(f32::INFINITY));
            ui.label("Existing verified files are reused. Your saves are not modified.");
            ui.separator();
            ui.columns(2, |cols| {
                cols[0].heading("Available versions");
                egui::ScrollArea::vertical().max_height(380.0).show(&mut cols[0], |ui| {
                    for v in &self.versions {
                        if !self.snapshots && v.kind != "release" { continue; }
                        if !v.id.to_lowercase().contains(&self.filter.to_lowercase()) { continue; }
                        let chosen = self.selected.as_ref().map(|s| s.id == v.id).unwrap_or(false);
                        if ui.selectable_label(chosen, format!("{}  ({})", v.id, v.kind)).clicked() { self.selected = Some(v.clone()); }
                    }
                });
                cols[1].heading("Installation");
                if let Some(v) = &self.selected { cols[1].label(format!("Selected: {}", v.id)); } else { cols[1].label("Choose a version on the left"); }
                if cols[1].add_enabled(!self.busy && self.selected.is_some(), egui::Button::new("⬇ Install selected version")).clicked() { self.install(); }
                if self.total > 0 { cols[1].add(egui::ProgressBar::new(self.completed as f32 / self.total as f32).show_percentage()); }
                cols[1].separator(); cols[1].label(&self.status);
                cols[1].add_space(10.0);
                cols[1].label("This version installs client, libraries, and assets. Microsoft login is implemented. Direct Play is planned for v0.5.");
            });
        });
        if self.busy || self.auth_busy { ctx.request_repaint_after(Duration::from_millis(100)); }
    }
}
fn client() -> Result<reqwest::blocking::Client, String> {
    reqwest::blocking::Client::builder().timeout(Duration::from_secs(90))
        .user_agent("BlockForge/0.4 (Minecraft Java installer)")
        .build().map_err(|e| e.to_string())
}
fn get_json<T: serde::de::DeserializeOwned>(client: &reqwest::blocking::Client, url: &str) -> Result<T, String> {
    let resp = client.get(url).send().map_err(|e| e.to_string())?.error_for_status().map_err(|e| e.to_string())?;
    resp.json().map_err(|e| format!("JSON at {url}: {e}"))
}
fn safe_relative(path: &str) -> Result<PathBuf, String> {
    use std::path::Component;
    let p = Path::new(path);
    if p.components().any(|c| !matches!(c, Component::Normal(_))) { return Err(format!("Unsafe path: {path}")); }
    Ok(p.to_path_buf())
}
fn download_file(client: &reqwest::blocking::Client, url: &str, target: &Path, expected_hash: Option<&str>, expected_size: Option<u64>) -> Result<(), String> {
    if target.is_file() && verify(target, expected_hash, expected_size)? { return Ok(()); }
    if let Some(parent) = target.parent() { fs::create_dir_all(parent).map_err(|e| e.to_string())?; }
    let temp = target.with_extension("blockforge-part");
    let result = (|| -> Result<(), String> {
        let mut response = client.get(url).send().map_err(|e| e.to_string())?.error_for_status().map_err(|e| e.to_string())?;
        let mut out = fs::File::create(&temp).map_err(|e| e.to_string())?;
        std::io::copy(&mut response, &mut out).map_err(|e| e.to_string())?;
        out.flush().map_err(|e| e.to_string())?;
        if !verify(&temp, expected_hash, expected_size)? { return Err(format!("Downloaded file failed integrity check: {url}")); }
        if target.exists() { fs::remove_file(target).map_err(|e| e.to_string())?; }
        fs::rename(&temp, target).map_err(|e| e.to_string())?;
        Ok(())
    })();
    if result.is_err() { let _ = fs::remove_file(&temp); }
    result
}
fn verify(path: &Path, hash: Option<&str>, size: Option<u64>) -> Result<bool, String> {
    let Ok(meta) = fs::metadata(path) else { return Ok(false); };
    if let Some(n) = size { if meta.len() != n { return Ok(false); } }
    if let Some(hash) = hash {
        let mut file = fs::File::open(path).map_err(|e| e.to_string())?;
        let mut hasher = Sha1::new();
        std::io::copy(&mut file, &mut hasher).map_err(|e| e.to_string())?;
        return Ok(format!("{:x}", hasher.finalize()).eq_ignore_ascii_case(hash));
    }
    Ok(true)
}
fn allowed(rules: &Option<Vec<Rule>>) -> bool {
    let Some(rules) = rules else { return true; };
    let mut allow = false;
    for rule in rules {
        if rule.features.is_some() { continue; } // unknown optional feature conditions are not enabled
        let matches = rule.os.as_ref().map(|os| {
            os.name.as_deref().map(|n| n == "windows").unwrap_or(true)
            && os.arch.as_deref().map(|a| a == "x86_64" || a == "amd64").unwrap_or(true)
            && os.version.is_none() // regex-based OS rules not supported in this version
        }).unwrap_or(true);
        if matches { allow = rule.action == "allow"; }
    }
    allow
}
fn install_version(v: &Version, root: &Path, tx: &Sender<Event>) -> Result<(), String> {
    let client = client()?;
    let info: VersionInfo = get_json(&client, &v.url)?;
    let dir = root.join("versions").join(safe_relative(&v.id)?);
    fs::create_dir_all(&dir).map_err(|e| e.to_string())?;
    let metadata = dir.join(format!("{}.json", v.id));
    download_file(&client, &v.url, &metadata, None, None)?;
    let mut tasks: Vec<(String, PathBuf, Option<String>, Option<u64>)> = vec![];
    let c = &info.downloads.client;
    tasks.push((c.url.clone(), dir.join(format!("{}.jar", v.id)), c.sha1.clone(), c.size));
    for lib in info.libraries.iter().filter(|l| allowed(&l.rules)) {
        if let Some(downloads) = &lib.downloads {
            if let Some(artifact) = &downloads.artifact {
                if let Some(path) = &artifact.path {
                    tasks.push((artifact.url.clone(), root.join("libraries").join(safe_relative(path)?), artifact.sha1.clone(), artifact.size));
                }
            }
            if let Some(classifiers) = &downloads.classifiers {
                if let Some(native) = classifiers.get("natives-windows") {
                    if let Some(path) = &native.path {
                        tasks.push((native.url.clone(), root.join("libraries").join(safe_relative(path)?), native.sha1.clone(), native.size));
                    }
                }
            }
        }
    }
    if let Some(index) = &info.asset_index {
        let index_path = root.join("assets").join("indexes").join(format!("{}.json", v.id));
        download_file(&client, &index.url, &index_path, index.sha1.as_deref(), index.size)?;
        let bytes = fs::read(&index_path).map_err(|e| e.to_string())?;
        let assets: AssetIndex = serde_json::from_slice(&bytes).map_err(|e| e.to_string())?;
        for asset in assets.objects.values() {
            if asset.hash.len() != 40 || !asset.hash.bytes().all(|b| b.is_ascii_hexdigit()) { return Err("Invalid asset hash".into()); }
            let prefix = &asset.hash[..2];
            tasks.push((format!("https://resources.download.minecraft.net/{prefix}/{}", asset.hash),
                root.join("assets").join("objects").join(prefix).join(&asset.hash), Some(asset.hash.clone()), Some(asset.size)));
        }
    }
    let total = tasks.len();
    for (i, (url, path, hash, size)) in tasks.into_iter().enumerate() {
        let name = path.file_name().unwrap_or_default().to_string_lossy();
        let _ = tx.send(Event::Progress(format!("Downloading {} ({}/{})", name, i+1, total), i, total));
        download_file(&client, &url, &path, hash.as_deref(), size)?;
        let _ = tx.send(Event::Progress(format!("Verified {}", name), i+1, total));
    }
    Ok(())
}
fn main() -> eframe::Result<()> {
    let options = eframe::NativeOptions { viewport: egui::ViewportBuilder::default().with_inner_size([960.0, 640.0]).with_min_inner_size([700.0, 480.0]), ..Default::default() };
    eframe::run_native("BlockForge Launcher v0.4", options, Box::new(|cc| {
        cc.egui_ctx.set_visuals(egui::Visuals::dark());
        Ok(Box::new(App::new()))
    }))
}
