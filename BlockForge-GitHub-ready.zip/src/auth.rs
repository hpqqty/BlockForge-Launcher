use reqwest::blocking::Client;
use serde::Deserialize;
use serde_json::json;
use std::{sync::mpsc::Sender, thread, time::{Duration, Instant}};

pub enum AuthEvent {
    Code { code: String, url: String, message: String },
    Status(String),
    SignedIn { username: String, uuid: String },
    Error(String),
}

#[derive(Deserialize)]
struct DeviceCode { device_code: String, user_code: String, verification_uri: String, expires_in: u64, interval: Option<u64>, message: Option<String> }
#[derive(Deserialize)]
struct TokenResponse { access_token: String }
#[derive(Deserialize)]
struct XboxResponse { #[serde(rename = "Token")] token: String, #[serde(rename = "DisplayClaims")] display_claims: XboxClaims }
#[derive(Deserialize)]
struct XboxClaims { xui: Vec<Xui> }
#[derive(Deserialize)]
struct Xui { uhs: String }
#[derive(Deserialize)]
struct MinecraftToken { access_token: String }
#[derive(Deserialize)]
struct MinecraftProfile { id: String, name: String }

fn client() -> Result<Client, String> {
    Client::builder().timeout(Duration::from_secs(30))
        .user_agent("BlockForge/0.4")
        .build().map_err(|e| e.to_string())
}
fn error_text(status: reqwest::StatusCode, body: &str) -> String {
    let short = body.chars().take(500).collect::<String>();
    format!("HTTP {status}: {short}")
}
fn post_json(client: &Client, url: &str, value: serde_json::Value) -> Result<serde_json::Value, String> {
    let response = client.post(url).json(&value).send().map_err(|e| e.to_string())?;
    let status = response.status();
    let body = response.text().map_err(|e| e.to_string())?;
    if !status.is_success() { return Err(error_text(status, &body)); }
    serde_json::from_str(&body).map_err(|e| format!("Invalid JSON: {e}"))
}
fn xbox_auth(client: &Client, ms_token: &str) -> Result<XboxResponse, String> {
    let response = post_json(client, "https://user.auth.xboxlive.com/user/authenticate", json!({
        "Properties": {"AuthMethod": "RPS", "SiteName": "user.auth.xboxlive.com", "RpsTicket": format!("d={ms_token}")},
        "RelyingParty": "http://auth.xboxlive.com", "TokenType": "JWT"
    }))?;
    serde_json::from_value(response).map_err(|e| e.to_string())
}
fn xsts_auth(client: &Client, xbox_token: &str) -> Result<XboxResponse, String> {
    let response = post_json(client, "https://xsts.auth.xboxlive.com/xsts/authorize", json!({
        "Properties": {"SandboxId": "RETAIL", "UserTokens": [xbox_token]},
        "RelyingParty": "rp://api.minecraftservices.com/", "TokenType": "JWT"
    }))?;
    serde_json::from_value(response).map_err(|e| e.to_string())
}

pub fn sign_in(client_id: String, tx: Sender<AuthEvent>) {
    let result = sign_in_inner(&client_id, &tx);
    if let Err(e) = result { let _ = tx.send(AuthEvent::Error(e)); }
}
fn sign_in_inner(client_id: &str, tx: &Sender<AuthEvent>) -> Result<(), String> {
    if client_id.trim().is_empty() { return Err("Enter your Microsoft application client ID first.".into()); }
    let client = client()?;
    let device_url = "https://login.microsoftonline.com/consumers/oauth2/v2.0/devicecode";
    let token_url = "https://login.microsoftonline.com/consumers/oauth2/v2.0/token";
    let response = client.post(device_url).form(&[
        ("client_id", client_id), ("scope", "XboxLive.signin offline_access")
    ]).send().map_err(|e| e.to_string())?;
    let status = response.status();
    let body = response.text().map_err(|e| e.to_string())?;
    if !status.is_success() { return Err(error_text(status, &body)); }
    let device: DeviceCode = serde_json::from_str(&body).map_err(|e| e.to_string())?;
    let _ = tx.send(AuthEvent::Code {
        code: device.user_code.clone(), url: device.verification_uri.clone(),
        message: device.message.unwrap_or_else(|| "Open the verification page and enter the code.".into())
    });
    let deadline = Instant::now() + Duration::from_secs(device.expires_in);
    let mut interval = device.interval.unwrap_or(5).max(5);
    let ms_token = loop {
        if Instant::now() >= deadline { return Err("Sign-in code expired. Please try again.".into()); }
        thread::sleep(Duration::from_secs(interval));
        let response = client.post(token_url).form(&[
            ("client_id", client_id),
            ("grant_type", "urn:ietf:params:oauth:grant-type:device_code"),
            ("device_code", device.device_code.as_str())
        ]).send().map_err(|e| e.to_string())?;
        let status = response.status();
        let body = response.text().map_err(|e| e.to_string())?;
        if status.is_success() {
            let token: TokenResponse = serde_json::from_str(&body).map_err(|e| e.to_string())?;
            break token.access_token;
        }
        let value: serde_json::Value = serde_json::from_str(&body).unwrap_or_default();
        match value.get("error").and_then(|v| v.as_str()).unwrap_or("") {
            "authorization_pending" => continue,
            "slow_down" => { interval += 5; continue; }
            "authorization_declined" => return Err("Microsoft sign-in was declined.".into()),
            "expired_token" => return Err("Sign-in code expired.".into()),
            _ => return Err(error_text(status, &body)),
        }
    };
    let _ = tx.send(AuthEvent::Status("Microsoft authenticated. Contacting Xbox Live...".into()));
    let xbox = xbox_auth(&client, &ms_token)?;
    let _ = tx.send(AuthEvent::Status("Getting Xbox security token...".into()));
    let xsts = xsts_auth(&client, &xbox.token)?;
    let uhs = xsts.display_claims.xui.first().ok_or("Missing Xbox user hash")?.uhs.as_str();
    let _ = tx.send(AuthEvent::Status("Authenticating with Minecraft Services...".into()));
    let mc_value = post_json(&client, "https://api.minecraftservices.com/authentication/login_with_xbox", json!({
        "identityToken": format!("XBL3.0 x={uhs};{}", xsts.token)
    }))?;
    let mc: MinecraftToken = serde_json::from_value(mc_value).map_err(|e| e.to_string())?;
    let _ = tx.send(AuthEvent::Status("Checking Minecraft Java profile...".into()));
    let response = client.get("https://api.minecraftservices.com/minecraft/profile")
        .bearer_auth(&mc.access_token).send().map_err(|e| e.to_string())?;
    let status = response.status();
    let body = response.text().map_err(|e| e.to_string())?;
    if !status.is_success() {
        return Err(format!("Minecraft profile unavailable (HTTP {status}). Confirm this Microsoft account owns Minecraft Java Edition. Details: {}", body.chars().take(250).collect::<String>()));
    }
    let profile: MinecraftProfile = serde_json::from_str(&body).map_err(|e| e.to_string())?;
    if profile.name.is_empty() || profile.id.is_empty() { return Err("Minecraft profile is incomplete.".into()); }
    let _ = tx.send(AuthEvent::SignedIn { username: profile.name, uuid: profile.id });
    Ok(())
}
