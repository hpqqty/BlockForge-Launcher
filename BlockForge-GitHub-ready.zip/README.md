# BlockForge Launcher

An experimental, independent **Minecraft Java Edition version manager and installer** written in Rust using `eframe`/`egui`.

> **Development status: early alpha.** This project is unaffiliated with Mojang Studios, Minecraft, Microsoft, or Xbox. It is not yet a complete replacement for the official Minecraft Launcher.

## Features

- Dark desktop interface for Windows
- Minecraft Java Edition version list from Mojang's official manifest
- Download and install Minecraft client files, dependencies, and assets
- Microsoft device-code OAuth sign-in and Xbox Live / XSTS authentication
- Minecraft Services profile lookup (subject to approval of the app registration)

## Authentication and Minecraft API access

BlockForge asks the user to authenticate directly with Microsoft through the official device-code flow. After authorization, it uses Xbox Live/XSTS and Minecraft Services to check ownership and retrieve the player's Minecraft Java Edition username and UUID.

**Minecraft Services access is pending application registration approval.** Some Microsoft sign-ins may succeed while Minecraft Services rejects the app with HTTP 403 `Invalid app registration`.

The application's public OAuth Client ID is supplied by the developer/user in the current alpha version. **No client secret should be used** in this desktop application. Account passwords are not collected by BlockForge. Authentication tokens are not intentionally persisted by this alpha build; do not share them in issues or screenshots.

## Requirements

- Windows 10 or 11
- Rust toolchain ([rustup](https://rustup.rs/))
- Internet connection
- A legitimately owned Minecraft Java Edition license for account verification
- A Microsoft public-client application registration enabled for device-code sign-in, with necessary Minecraft service approvals

## Build and run

```powershell
cargo run --release
```

## Current limitations

- **Direct game launching is not implemented.** Minecraft files are downloaded/installed, but BlockForge does not yet launch the game directly.
- Dependency and native handling may not be complete for all Minecraft versions.
- Microsoft OAuth authorization is implemented, but Minecraft Services approval is required before the full sign-in sequence can succeed.
- No persistent account/session management yet.

## Privacy and security

- Microsoft credentials are entered only on Microsoft's website.
- Do not open issues containing passwords, device codes, OAuth access/refresh tokens, or private account information.
- Never commit `target/`, build artifacts, credentials, or local account data.

## Technology

Rust · `eframe` / `egui` · `reqwest` · `serde` · Minecraft Java Edition metadata and authentication APIs.

## Project goal

Build a straightforward desktop Minecraft Java Edition launcher with official-version management, account verification, and eventually direct launching and mod-loader support.
